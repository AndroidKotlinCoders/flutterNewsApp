class Constant{
  static const String newsApiKey = 'API_KEY_HERE';
  static const String baseUrl = 'https://newsapi.org/v2/';
  static const String topHeadLine = '/top-headlines';
}