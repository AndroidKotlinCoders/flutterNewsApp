export 'detail_bloc.dart';
export 'detail_event.dart';
export 'detail_state.dart';